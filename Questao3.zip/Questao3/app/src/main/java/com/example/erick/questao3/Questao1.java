package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Questao1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao1);

        Button melhor = findViewById(R.id.butao_melhor_combustivel);
        melhor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Questao1.this, MelhorCombustivel.class);
                Questao1.this.startActivity(myIntent);
            }
        });
        Button consumo = findViewById(R.id.butao_consumo_medio);
        consumo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Questao1.this, ConsumoMedio.class);
                Questao1.this.startActivity(myIntent);
            }
        });
    }
}
