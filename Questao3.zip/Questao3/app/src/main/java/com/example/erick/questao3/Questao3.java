package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Questao3 extends AppCompatActivity {

    public float getSalarioLiquido(float salario_bruto) {
        float salario_liquido = INSS.getSalarioDescontado(salario_bruto);
        salario_liquido = IRPF.getSalarioDescontado(salario_liquido);
        return salario_liquido;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao3);
        EditText salario = findViewById(R.id.salario_bruto);
        salario.addTextChangedListener(getWatcher());
        Button inss = findViewById(R.id.butao_inss);
        inss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText text = findViewById(R.id.salario_bruto);
                if (text != null) {
                    Intent myIntent = new Intent(Questao3.this, INSS.class);
                    Bundle bundle = new Bundle();
                    bundle.putFloat("salario_bruto", Float.parseFloat(text.getText().toString()));
                    myIntent.putExtras(bundle);
                    Questao3.this.startActivity(myIntent);
                }
            }
        });
        Button irpf = findViewById(R.id.butao_irpf);
        irpf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText text = findViewById(R.id.salario_bruto);
                if (text != null) {
                    Intent myIntent = new Intent(Questao3.this, IRPF.class);
                    Bundle bundle = new Bundle();
                    bundle.putFloat("salario_bruto", INSS.getSalarioDescontado(Float.parseFloat(text.getText().toString())));
                    myIntent.putExtras(bundle);
                    Questao3.this.startActivity(myIntent);
                }
            }
        });
    }

    private TextWatcher getWatcher() {
        return new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals("")) {
                    TextView salarioLiquido = findViewById(R.id.salario_liquido);
                    float salario_bruto = Float.parseFloat(s.toString());
                    salarioLiquido.setText(String.valueOf(getSalarioLiquido(salario_bruto)));
                } else {
                    TextView salarioLiquido = findViewById(R.id.salario_liquido);
                    salarioLiquido.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
    }
}
