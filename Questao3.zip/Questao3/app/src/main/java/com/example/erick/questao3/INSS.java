package com.example.erick.questao3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class INSS extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inss);
        float salario_bruto = getIntent().getExtras().getFloat("salario_bruto");
        float descontoINSS = INSS.getDescontoINSS(salario_bruto);
        ((TextView)findViewById(R.id.desconto_inss)).setText(String.valueOf(descontoINSS));
        ((TextView)findViewById(R.id.faixa_inss)).setText(getFaixa(salario_bruto).toString());
    }

    private static boolean isEntreValores(float salario, FaixaINSS faixa) {
        return faixa.getMinimo() <= salario && salario <= faixa.getMaximo();
    }

    public static FaixaINSS getFaixa(float salario) {
        for (FaixaINSS faixa : FaixaINSS.values()) {
            if (isEntreValores(salario, faixa)) {
                return faixa;
            }
        }
        return null;
    }

    public static float getSalarioDescontado(float salario) {
        return salario - getDescontoINSS(salario);
    }

    public static float getDescontoINSS(float salario) {
        return salario * getFaixa(salario).getTaxa() / 100.0f;
    }
}
