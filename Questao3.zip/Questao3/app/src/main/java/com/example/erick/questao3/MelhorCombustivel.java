package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MelhorCombustivel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_melhor_combustivel);

        Button melhor = findViewById(R.id.calcular_melhor_combustivel);
        melhor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etanolText = findViewById(R.id.valor_etanol);
                float valorEtanol = Float.parseFloat(etanolText.getText().toString());
                EditText gasolinaText = findViewById(R.id.valor_gasolina);
                float valorGasolina = Float.parseFloat( gasolinaText.getText().toString());
                TextView resultado = findViewById(R.id.melhor_combustivel);
                if (valorEtanol / valorGasolina >= 0.7f) {
                    resultado.setText("Gasolina");
                } else {
                    resultado.setText("Etanol");
                }
            }
        });
    }
}
