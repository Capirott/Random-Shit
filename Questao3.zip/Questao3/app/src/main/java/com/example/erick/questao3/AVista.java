package com.example.erick.questao3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AVista extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avista);

        Button calcular = findViewById(R.id.calcular_avista);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView valor_a_pagar = findViewById(R.id.valor_a_pagar);
                EditText descontoText = findViewById(R.id.desconto_avista);
                float desconto = Float.parseFloat(descontoText.getText().toString());
                float valor = getIntent().getExtras().getFloat("valor");
                valor_a_pagar.setText(String.valueOf(valor - valor * desconto / 100.0f));
            }
        });
    }
}
