package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Parcelado2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelado2);
        Button continuar = findViewById(R.id.butao_continuar2);
        continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Parcelado2.this, ParceladoResultado.class);
                Bundle bundle = new Bundle();
                EditText valorText = findViewById(R.id.percentual_juros);
                bundle.putFloat("valor", getIntent().getExtras().getFloat("valor"));
                bundle.putFloat("quantidade", getIntent().getExtras().getFloat("quantidade"));
                bundle.putFloat("percentual", Float.parseFloat(valorText.getText().toString()));
                myIntent.putExtras(bundle);
                Parcelado2.this.startActivity(myIntent);
            }
        });
    }
}
