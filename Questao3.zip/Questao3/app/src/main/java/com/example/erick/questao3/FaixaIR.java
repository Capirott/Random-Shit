package com.example.erick.questao3;

public enum FaixaIR {
    FAIXAA(0.0f, 1903.98f, 0.0f, 0.0f),
    FAIXAB(1903.99f, 2826.65f, 7.5f, 142.80f),
    FAIXAC(2826.66f, 3751.05f, 15.0f, 354.90f),
    FAIXAD(3751.06f, 4664.68f, 22.5f, 635.13f),
    FAIXAE(4664.68f, Float.MAX_VALUE, 27.5f, 869.36f);

    private float minimo;
    private float maximo;
    private float taxa;
    private float deducao;

    private FaixaIR(float minimo, float maximo, float taxa, float deducao) {
        this.minimo = minimo;
        this.maximo = maximo;
        this.taxa = taxa;
        this.deducao = deducao;
    }

    @Override
    public String toString() {
        if (taxa < 0.1f) {
            return "Até 1.903,98";
        } else if (taxa < 7.6f) {
            return "De 1.903,99 Até 2.826,65";
        }
        else if (taxa < 15.1f) {
            return "De 2.826,66 Até 3.751,05";
        } else if (taxa < 22.6f) {
            return "De 3.751,06 Até 4.664,68";
        } else if (taxa < 27.6) {
            return "Acima De 4.664,68";
        } else {
            return "Faixa não determinada!";
        }
    }

    public float getMinimo() {
        return minimo;
    }

    public float getMaximo() {
        return maximo;
    }

    public float getTaxa() {
        return taxa;
    }

    public float getDeducao() {
        return deducao;
    }
}
