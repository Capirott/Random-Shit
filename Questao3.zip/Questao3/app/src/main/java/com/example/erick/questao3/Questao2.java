package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Questao2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questao2);

        Button vista = findViewById(R.id.butao_vista);
        vista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Questao2.this, AVista.class);
                Bundle bundle = new Bundle();
                EditText valorText = findViewById(R.id.valor_pagamento);
                bundle.putFloat("valor", Float.parseFloat(valorText.getText().toString()));
                myIntent.putExtras(bundle);
                Questao2.this.startActivity(myIntent);
            }
        });
        Button parcelado = findViewById(R.id.butao_parcelado);
        parcelado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(Questao2.this, Parcelado.class);
                Bundle bundle = new Bundle();
                EditText valorText = findViewById(R.id.valor_pagamento);
                bundle.putFloat("valor", Float.parseFloat(valorText.getText().toString()));
                myIntent.putExtras(bundle);
                Questao2.this.startActivity(myIntent);
            }
        });

    }
}
