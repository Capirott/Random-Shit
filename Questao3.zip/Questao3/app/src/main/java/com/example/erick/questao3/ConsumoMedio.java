package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ConsumoMedio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumo_medio);
        Button calcular = findViewById(R.id.calcular_consumo_medio);
        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText quiloText = findViewById(R.id.quilometragem);
                float valorKm = Float.parseFloat(quiloText.getText().toString());
                EditText litroText = findViewById(R.id.litros);
                float valorLitro = Float.parseFloat( litroText.getText().toString());
                float ltsPerKm = valorKm / valorLitro;
                Intent myIntent = new Intent(ConsumoMedio.this, ConsumoMedioResultado.class);
                Bundle bundle = new Bundle();
                bundle.putFloat("ltsPerKm", ltsPerKm);
                myIntent.putExtras(bundle);
                ConsumoMedio.this.startActivity(myIntent);
            }
        });
    }
}
