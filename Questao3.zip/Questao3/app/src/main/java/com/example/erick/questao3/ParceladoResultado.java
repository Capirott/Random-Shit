package com.example.erick.questao3;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ParceladoResultado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelado_resultado);
        Bundle extras = getIntent().getExtras();
        float valor = extras.getFloat("valor");
        float quantidade = extras.getFloat("quantidade");
        float percentual = extras.getFloat("percentual");
        float valor_com_juros = valor + valor * percentual / 100.0f;
        TextView resultado = findViewById(R.id.valor_parcela);
        resultado.setText(String.valueOf(valor_com_juros / quantidade));
    }
}
