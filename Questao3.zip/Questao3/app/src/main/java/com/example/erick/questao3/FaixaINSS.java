package com.example.erick.questao3;

public enum FaixaINSS {
    FAIXAA(0.0f, 1693.72f, 8),
    FAIXAB(1693.73f, 2822.90f, 9),
    FAIXAC(2822.91f, 5645.80f, 11);

    private float minimo;
    private float maximo;
    private int taxa;

    private FaixaINSS(float minimo, float maximo, int taxa) {
        this.minimo = minimo;
        this.maximo = maximo;
        this.taxa   = taxa;
    }

    @Override
    public String toString() {
        switch (taxa) {
            case 8:
                return "Até R$ 1.693,72";
            case 9:
                return "De R$ 1.693,73 a R$ 2.822,90";
            default:
                return "De R$ 2.822,91 até R$ 5.645,80";
        }
    }

    public float getMinimo() {
        return minimo;
    }

    public float getMaximo() {
        return maximo;
    }

    public int getTaxa() {
        return taxa;
    }
}
