package com.example.erick.questao3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button questao_1 = findViewById(R.id.questao_1);
        questao_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, Questao1.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
        Button questao_2 = findViewById(R.id.questao_2);
        questao_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, Questao2.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
        Button questao_3 = findViewById(R.id.questao_3);
        questao_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, Questao3.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }
}
