package com.example.erick.questao3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import org.w3c.dom.Text;

public class ConsumoMedioResultado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumo_medio_resultado);
        TextView text = findViewById(R.id.consumo_medio);
        text.setText(String.valueOf(getIntent().getExtras().getFloat("ltsPerKm")));
    }
}
