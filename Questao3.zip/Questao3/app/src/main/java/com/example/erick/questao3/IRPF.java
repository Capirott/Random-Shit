package com.example.erick.questao3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class IRPF extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_irpf);
        float salario_bruto = getIntent().getExtras().getFloat("salario_bruto");
        float descontoIRPF = IRPF.getDesconto(salario_bruto);
        ((TextView)findViewById(R.id.desconto_irpf)).setText(String.valueOf(descontoIRPF));
        ((TextView)findViewById(R.id.faixa_irpf)).setText(getFaixa(salario_bruto).toString());
    }

    private static boolean isEntreValores(float salario, FaixaIR faixa) {
        return faixa.getMinimo() <= salario && salario <= faixa.getMaximo();
    }

    public static FaixaIR getFaixa(float salario) {
        for (FaixaIR faixa : FaixaIR.values()) {
            if (isEntreValores(salario, faixa)) {
                return faixa;
            }
        }
        return null;
    }

    public static float getSalarioDescontado(float salario) {
        return salario - getDesconto(salario);
    }

    public static float getDesconto(float salario) {
        FaixaIR faixa = getFaixa(salario);
        return salario * faixa.getTaxa() / 100.0f - faixa.getDeducao();
    }
}