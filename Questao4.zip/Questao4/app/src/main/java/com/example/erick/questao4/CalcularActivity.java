package com.example.erick.questao4;

import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class CalcularActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular);

        Bundle extras = getIntent().getExtras();
        Integer quantidade = extras.getInt("quantidade");
        String codigo = extras.getString("codigo");
        if (quantidade != null && codigo != null) {
            float valorUnitario = 0.0f;
        switch (codigo) {
            case "101":
                valorUnitario = 29.99f;
                break;
            case "102":
                valorUnitario = 70.00f;
                break;
            case "103":
                valorUnitario = 85.75f;
                break;
            case "104":
                valorUnitario = 199.00f;
                break;
                default:
//                    Codigo nao encontrado
                break;
        }
            float valorTotal = valorUnitario * quantidade;

            float desconto = 15.0f;

        if (valorTotal <= 250.00f) {
            desconto = 5.0f;
        } else if (valorTotal <= 500.00f) {
            desconto = 10.0f;
        }

        float valorDesconto = valorTotal * desconto / 100.00f;

        float precoFinal = valorTotal - valorDesconto;


        ImageView imageView = findViewById(R.id.imagem_produto);

        String fnm = "i" + codigo; //  this is image file name
        String PACKAGE_NAME = getApplicationContext().getPackageName();
        int imgId = getResources().getIdentifier(PACKAGE_NAME+":drawable/"+fnm , null, null);
        imageView.setImageBitmap(BitmapFactory.decodeResource(getResources(),imgId));

        TextView precoUnitarioView = findViewById(R.id.preco_unitario);
        setValor(valorUnitario, precoUnitarioView);

        TextView precoTotalSemDescontoView = findViewById(R.id.total_sem_desconto);
        setValor(valorTotal, precoTotalSemDescontoView);

        TextView valorDescontoView = findViewById(R.id.valor_desconto);
        setValor(valorDesconto, valorDescontoView);

        TextView precoFinalView = findViewById(R.id.preco_final);
        setValor(precoFinal, precoFinalView);
        }

    }

    private void setValor(float valor, TextView precoUnitarioView) {
        NumberFormat formatter = new DecimalFormat("#0.00");
        precoUnitarioView.setText(formatter.format(valor));
    }
}
