package com.example.erick.questao4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b = findViewById(R.id.calcular_button);
        if (b != null) {
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    EditText codigoView = findViewById(R.id.codigo);
                    EditText quantidadeView = findViewById(R.id.quantidade);
                    String codigo = codigoView.getText().toString().trim();
                    Integer quantidade = Integer.parseInt(quantidadeView.getText().toString());

                    if (quantidade == null || quantidade.equals(0)) {
                        Toast toast= Toast.makeText(getApplicationContext(),"Quantidade invalida",Toast.LENGTH_SHORT);
                        toast.setMargin(50,50);
                        toast.show();
                        return;
                    }

                    if (codigo == null || codigo.trim().equals("") || !codigo.equals("101") && !codigo.equals("102") && !codigo.equals("103") &&  !codigo.equals("104") && !codigo.equals("105")) {
                        Toast toast=Toast.makeText(getApplicationContext(),"Codigo Invalido",Toast.LENGTH_SHORT);
                        toast.setMargin(50,50);
                        toast.show();
                        return;
                    }

                    Bundle extra = new Bundle();
                    extra.putString("codigo", codigo);
                    extra.putInt("quantidade", quantidade);
                    Intent myIntent = new Intent(MainActivity.this, CalcularActivity.class);
                    myIntent.putExtras(extra);
                    MainActivity.this.startActivity(myIntent);
                }
            });
        }
    }
}
